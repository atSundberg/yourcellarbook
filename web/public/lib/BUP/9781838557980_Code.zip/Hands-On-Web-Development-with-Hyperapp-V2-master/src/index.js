import hypernews from './hypernews.js';

hypernews();
